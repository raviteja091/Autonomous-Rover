# Wheel_Odometry library for micro controllers.
Wheel odometry library for publishing odometry messages using motor encoder values.
This library can be used for publishing odometry messages from a microcontroller to ros2 topic via micro-ROS. This code is took from [linorobot2_hardware](https://github.com/linorobot/linorobot2_hardware) 

