#define FORWARD 1
#define REVERSE 2

// Define motor control pins for all 4 motors
#define Mot1Fwd 12  // Motor 1 Forward pin
#define Mot1Rev 15  // Motor 1 Reverse pin
#define Mot2Fwd 16  // Motor 2 Forward pin
#define Mot2Rev 17  // Motor 2 Reverse pin
#define Mot3Fwd 4   // Motor 3 Forward pin
#define Mot3Rev 5   // Motor 3 Reverse pin
#define Mot4Fwd 18  // Motor 4 Forward pin
#define Mot4Rev 19  // Motor 4 Reverse pin

// Encoder pins for each motor
int encoderPin1_A = 23, encoderPin1_B = 25;
int encoderPin2_A = 34, encoderPin2_B = 35;
int encoderPin3_A = 32, encoderPin3_B = 33;
int encoderPin4_A = 26, encoderPin4_B = 27;

volatile int lastEncoded1 = 0, lastEncoded2 = 0, lastEncoded3 = 0, lastEncoded4 = 0;
volatile long encoderValue1 = 0, encoderValue2 = 0, encoderValue3 = 0, encoderValue4 = 0;

void updateEncoder1();
void updateEncoder2();
void updateEncoder3();
void updateEncoder4();
void stopMotors();
void moveForward();
void moveBackward();
void moveRight();
void moveLeft();

void motor_Init() {
  // Setup motor pins
  pinMode(Mot1Fwd, OUTPUT);
  pinMode(Mot1Rev, OUTPUT);
  pinMode(Mot2Fwd, OUTPUT);
  pinMode(Mot2Rev, OUTPUT);
  pinMode(Mot3Fwd, OUTPUT);
  pinMode(Mot3Rev, OUTPUT);
  pinMode(Mot4Fwd, OUTPUT);
  pinMode(Mot4Rev, OUTPUT);

  // Setup encoder pins
  pinMode(encoderPin1_A, INPUT_PULLUP);
  pinMode(encoderPin1_B, INPUT_PULLUP);
  pinMode(encoderPin2_A, INPUT_PULLUP);
  pinMode(encoderPin2_B, INPUT_PULLUP);
  pinMode(encoderPin3_A, INPUT_PULLUP);
  pinMode(encoderPin3_B, INPUT_PULLUP);
  pinMode(encoderPin4_A, INPUT_PULLUP);
  pinMode(encoderPin4_B, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(encoderPin1_A), updateEncoder1, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoderPin1_B), updateEncoder1, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoderPin2_A), updateEncoder2, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoderPin2_B), updateEncoder2, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoderPin3_A), updateEncoder3, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoderPin3_B), updateEncoder3, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoderPin4_A), updateEncoder4, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoderPin4_B), updateEncoder4, CHANGE);
}


void moveMotor(int motor, int direction) {
  switch (motor) {
    case 1:
      if (direction == FORWARD) {
        digitalWrite(Mot1Fwd, HIGH);
        digitalWrite(Mot1Rev, LOW);
      } else {
        digitalWrite(Mot1Fwd, LOW);
        digitalWrite(Mot1Rev, HIGH);
      }
      break;
    case 2:
      if (direction == FORWARD) {
        digitalWrite(Mot2Fwd, HIGH);
        digitalWrite(Mot2Rev, LOW);
      } else {
        digitalWrite(Mot2Fwd, LOW);
        digitalWrite(Mot2Rev, HIGH);
      }
      break;
    case 3:
      if (direction == FORWARD) {
        digitalWrite(Mot3Fwd, HIGH);
        digitalWrite(Mot3Rev, LOW);
      } else {
        digitalWrite(Mot3Fwd, LOW);
        digitalWrite(Mot3Rev, HIGH);
      }
      break;
    case 4:
      if (direction == FORWARD) {
        digitalWrite(Mot4Fwd, HIGH);
        digitalWrite(Mot4Rev, LOW);
      } else {
        digitalWrite(Mot4Fwd, LOW);
        digitalWrite(Mot4Rev, HIGH);
      }
      break;
  }
}

void updateEncoder1() {
  int MSB = digitalRead(encoderPin1_A);
  int LSB = digitalRead(encoderPin1_B);
  int encoded = (MSB << 1) | LSB;
  int sum = (lastEncoded1 << 2) | encoded;
  if (sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011) encoderValue1--;
  if (sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000) encoderValue1++;
  lastEncoded1 = encoded;
}

void updateEncoder2() {
  int MSB = digitalRead(encoderPin2_A);
  int LSB = digitalRead(encoderPin2_B);
  int encoded = (MSB << 1) | LSB;
  int sum = (lastEncoded2 << 2) | encoded;
  if (sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011) encoderValue2--;
  if (sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000) encoderValue2++;
  lastEncoded2 = encoded;
}

void updateEncoder3() {
  int MSB = digitalRead(encoderPin3_A);
  int LSB = digitalRead(encoderPin3_B);
  int encoded = (MSB << 1) | LSB;
  int sum = (lastEncoded3 << 2) | encoded;
  if (sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011) encoderValue3--;
  if (sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000) encoderValue3++;
  lastEncoded3 = encoded;
}

void updateEncoder4() {
  int MSB = digitalRead(encoderPin4_A);
  int LSB = digitalRead(encoderPin4_B);
  int encoded = (MSB << 1) | LSB;
  int sum = (lastEncoded4 << 2) | encoded;
  if (sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011) encoderValue4--;
  if (sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000) encoderValue4++;
  lastEncoded4 = encoded;
}


void TestMotor() {
  // Example of moving motors forward and reverse and printing encoder values
  moveMotor(1, FORWARD);
  moveMotor(2, FORWARD);
  moveMotor(3, FORWARD);
  moveMotor(4, FORWARD);
  delay(1000);
  stopMotors();
  Serial.print("Motor 1 Encoder Value: ");
  Serial.println(encoderValue1);
  Serial.print("Motor 2 Encoder Value: ");
  Serial.println(encoderValue2);
  Serial.print("Motor 3 Encoder Value: ");
  Serial.println(encoderValue3);
  Serial.print("Motor 4 Encoder Value: ");
  Serial.println(encoderValue4);

  delay(1000);

  moveMotor(1, REVERSE);
  moveMotor(2, REVERSE);
  moveMotor(3, REVERSE);
  moveMotor(4, REVERSE);
  delay(1000);
  stopMotors();
  delay(1000);
}


// Define motor control functions 
void moveForward() {
  moveMotor(1, FORWARD);
  moveMotor(2, FORWARD);
  moveMotor(3, FORWARD);
  moveMotor(4, FORWARD);
  delay(1000);  // Adjust delay for desired forward distance
  stopMotors();
  
}

void moveBackward() {
  moveMotor(1, REVERSE);
  moveMotor(2, REVERSE);
  moveMotor(3, REVERSE);
  moveMotor(4, REVERSE);
  delay(1000);  // Adjust delay for desired backward distance
  stopMotors();

}

void moveLeft() {
  moveMotor(1, REVERSE);
  moveMotor(2, FORWARD);
  moveMotor(3, REVERSE);
  moveMotor(4, FORWARD);
  delay(500);  // Adjust delay for desired left turn angle
  stopMotors();
}

void moveRight() {
  moveMotor(1, FORWARD);
  moveMotor(2, REVERSE);
  moveMotor(3, FORWARD);
  moveMotor(4, REVERSE);
  delay(500);  // Adjust delay for desired right turn angle
  stopMotors();

}

// Function to stop all motors
void stopMotors() {
  digitalWrite(Mot1Fwd, LOW);
  digitalWrite(Mot1Rev, LOW);
  digitalWrite(Mot2Fwd, LOW);
  digitalWrite(Mot2Rev, LOW);
  digitalWrite(Mot3Fwd, LOW);
  digitalWrite(Mot3Rev, LOW);
  digitalWrite(Mot4Fwd, LOW);
  digitalWrite(Mot4Rev, LOW);
}