// Global variables to store MPU9250 orientation data
float pitch = 0.0;    // Holds the pitch angle
float roll = 0.0;     // Holds the roll angle
float yaw = 0.0;      // Holds the yaw angle

// Function to initialize MPU9250
void IMU_init() {
  Wire.begin();                       // Start I2C communication
  delay(2000);                        // Allow time for MPU9250 to initialize

  // Attempt to set up the MPU9250 with its I2C address (0x68)
  if (!mpu.setup(0x68)) {
    Serial.println("MPU9250 not connected. Check wiring or I2C address.");
    // Uncomment below to halt execution if initialization fails
    // while (true) {
    //   delay(5000);                // Wait indefinitely if MPU9250 fails to initialize
    // }
  } else {
    Serial.println("MPU9250 Initialization is Successful");
  }
}

// Function to update pitch, roll, and yaw values from MPU9250
void updateMPUValues() {
  // Check if new data is available from MPU9250
  if (mpu.update()) {
    static uint32_t prev_ms = millis();   // Store the last update time

    // Update every 25 milliseconds to avoid excessive data processing
    if (millis() - prev_ms > 25) {
      yaw = mpu.getYaw();                 // Retrieve the current yaw angle
      pitch = mpu.getPitch();              // Retrieve the current pitch angle
      roll = mpu.getRoll();                // Retrieve the current roll angle
      prev_ms = millis();                  // Reset the update time
    }
  }
}
