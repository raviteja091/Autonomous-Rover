#include <esp_now.h>
#include <WiFi.h>

// MAC address of the transmitter with OLED
uint8_t broadcastAddress[] = {0xD8, 0x13, 0x2A, 0xED, 0x7F, 0xB0};

// Variables to store incoming joystick, button, and orientation data
int joy1XVal, joy1YVal, joy1ButtonState;
int joy2XVal, joy2YVal, joy2ButtonState;
int button1State, button2State;
float incoming_pitch, incoming_roll, incoming_yaw;

// Variable to store the status of data transmission
String success;

// Structure to receive data from transmitter (matches the transmitter's outgoing structure)
typedef struct incoming_message {
    int jx1;            // Joystick 1 X-axis value
    int jy1;            // Joystick 1 Y-axis value
    int jb1;            // Joystick 1 button state

    int jx2;            // Joystick 2 X-axis value
    int jy2;            // Joystick 2 Y-axis value
    int jb2;            // Joystick 2 button state

    int b1;             // Extra Button 1 state
    int b2;             // Extra Button 2 state

    float theta_out;    // Pitch data from transmitter
    float phi_out;      // Roll data from transmitter
    float psi_out;      // Yaw data from transmitter
} incoming_message;

// Instance to hold received data
incoming_message incomingReadings;

// Structure to send data back to transmitter (matches the transmitter's incoming structure)
typedef struct outgoing_message {
    float theta_in;     // Pitch data to send
    float phi_in;       // Roll data to send
    float psi_in;       // Yaw data to send
} outgoing_message;

// Instance to hold data being sent back to transmitter
outgoing_message outgoingReadings;

esp_now_peer_info_t peerInfo;    // Information for ESP-NOW peer connection

// Callback when data is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  success = (status == ESP_NOW_SEND_SUCCESS) ? "Delivery Success :)" : "Delivery Fail :(";
}

// Callback when data is received
void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  memcpy(&incomingReadings, incomingData, sizeof(incomingReadings));  // Copy incoming data into structure

  // Store incoming joystick, button, and orientation data
  joy1XVal = incomingReadings.jx1;
  joy1YVal = incomingReadings.jy1;
  joy1ButtonState = incomingReadings.jb1;

  joy2XVal = incomingReadings.jx2;
  joy2YVal = incomingReadings.jy2;
  joy2ButtonState = incomingReadings.jb2;

  button1State = incomingReadings.b1;
  button2State = incomingReadings.b2;

  incoming_pitch = incomingReadings.theta_out;
  incoming_roll = incomingReadings.phi_out;
  incoming_yaw = incomingReadings.psi_out;

  // Uncomment to print received data for debugging
  /*
  Serial.print("Joystick 1 X: "); Serial.println(joy1XVal);
  Serial.print("Joystick 1 Y: "); Serial.println(joy1YVal);
  Serial.print("Joystick 1 Button: "); Serial.println(joy1ButtonState);
  Serial.print("Joystick 2 X: "); Serial.println(joy2XVal);
  Serial.print("Joystick 2 Y: "); Serial.println(joy2YVal);
  Serial.print("Joystick 2 Button: "); Serial.println(joy2ButtonState);
  Serial.print("Button 1: "); Serial.println(button1State);
  Serial.print("Button 2: "); Serial.println(button2State);
  Serial.print("Incoming Pitch: "); Serial.println(incoming_pitch);
  Serial.print("Incoming Roll: "); Serial.println(incoming_roll);
  Serial.print("Incoming Yaw: "); Serial.println(incoming_yaw);
  */
}

// Function to initialize Wi-Fi and ESP-NOW
void wifi_Init() {
  WiFi.mode(WIFI_STA);  // Set the device as a Wi-Fi station

  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }
  Serial.println("WiFi Initialization is Successful");

  esp_now_register_send_cb(OnDataSent);  // Register the send status callback
  esp_now_register_recv_cb(OnDataRecv);  // Register the receive callback

  // Configure peer connection
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    Serial.println("Failed to add peer");
    return;
  }
}

// Function to send orientation data back to transmitter
void wifisendData() {
  // Set values to send
  outgoingReadings.theta_in = pitch;
  outgoingReadings.phi_in = roll;
  outgoingReadings.psi_in = yaw;

  // Send message via ESP-NOW
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &outgoingReadings, sizeof(outgoingReadings));

  // Uncomment to print send result for debugging
  // Serial.println(result == ESP_OK ? "Sent with success" : "Error sending the data");
}
