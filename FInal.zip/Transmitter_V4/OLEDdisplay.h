// OLED display width and height in pixels
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

// Initialize an SSD1306 OLED display object for I2C communication
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void OLED_Init() {
  // Initialize the OLED display with I2C address 0x3C
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("OLED allocation failed"));  // Print error if initialization fails
    // Uncomment the line below to halt if OLED initialization fails
    // while (true);
  } else {
    Serial.println("OLED Initialization Successful");
  }
}

void OLEDDisplay() {
  // Clear the previous content on the OLED display
  display.clearDisplay();

  // Display Yaw value on OLED
  display.setCursor(0, 0);                // Set cursor at top-left corner
  display.print("Yaw: ");
  display.println(yaw, 2);                 // Display yaw value with 2 decimal points

  // Display Pitch value on OLED
  display.setCursor(0, 20);               // Set cursor slightly lower
  display.print("Pitch: ");
  display.println(pitch, 2);               // Display pitch value with 2 decimal points

  // Display Roll value on OLED
  display.setCursor(0, 40);               // Set cursor lower again for roll
  display.print("Roll: ");
  display.println(roll, 2);                // Display roll value with 2 decimal points

  // Refresh OLED to show new data
  display.display();
}
