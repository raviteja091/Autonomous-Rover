#include <esp_now.h>
#include <WiFi.h>

// Define the MAC address of the receiver
uint8_t broadcastAddress[] = {0xC8, 0xF0, 0x9E, 0xBA, 0x60, 0x9C};

// Variables to store incoming orientation readings
float incoming_theta;
float incoming_phi;
float incoming_psi;

// Variable to store the status of data transmission
String success;

// Structure for outgoing data (must match the receiver's structure)
typedef struct outgoing_message {
    int jx1;          // Joystick 1 X-axis value
    int jy1;          // Joystick 1 Y-axis value
    int jb1;          // Joystick 1 button state

    int jx2;          // Joystick 2 X-axis value
    int jy2;          // Joystick 2 Y-axis value
    int jb2;          // Joystick 2 button state

    int b1;           // Extra Button 1 state
    int b2;           // Extra Button 2 state

    float theta_out;  // Pitch data to send
    float phi_out;    // Roll data to send
    float psi_out;    // Yaw data to send
} outgoing_message;

// Create an instance of outgoing data structure
outgoing_message outgoingReadings;

// Structure for incoming data (must match the sender's structure)
typedef struct incoming_message {
    float theta_in;   // Incoming pitch data
    float phi_in;     // Incoming roll data
    float psi_in;     // Incoming yaw data
} incoming_message;

// Create an instance of incoming data structure
incoming_message incomingReadings;

// Peer information for ESP-NOW
esp_now_peer_info_t peerInfo;

// Callback function for data sent status
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  // Update success status message based on the send result
  success = (status == ESP_NOW_SEND_SUCCESS) ? "Delivery Success :)" : "Delivery Fail :(";
}

// Callback function for received data
void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  // Copy incoming data into incomingReadings structure
  memcpy(&incomingReadings, incomingData, sizeof(incomingReadings));

  // Update global variables with the received values
  incoming_theta = incomingReadings.theta_in;
  incoming_phi = incomingReadings.phi_in;
  incoming_psi = incomingReadings.psi_in;
}

void wifi_Init() {
  // Set device to Wi-Fi Station mode
  WiFi.mode(WIFI_STA);

  // Initialize ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }
  Serial.println("WiFi Initialization is Successful");

  // Register the send callback to get status of transmitted packet
  esp_now_register_send_cb(OnDataSent);

  // Configure peer information
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;

  // Add peer and register receive callback
  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    Serial.println("Failed to add peer");
    return;
  }
  esp_now_register_recv_cb(OnDataRecv);
}

void wifisendData() {
  // Populate outgoing structure with joystick, button, and IMU values
  outgoingReadings.jx1 = joy1XVal;
  outgoingReadings.jy1 = joy1YVal;
  outgoingReadings.jb1 = joy1ButtonState;

  outgoingReadings.jx2 = joy2XVal;
  outgoingReadings.jy2 = joy2YVal;
  outgoingReadings.jb2 = joy2ButtonState;

  outgoingReadings.b1 = button1State;
  outgoingReadings.b2 = button2State;

  outgoingReadings.theta_out = pitch;
  outgoingReadings.phi_out = roll;
  outgoingReadings.psi_out = yaw;

  // Send data via ESP-NOW
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &outgoingReadings, sizeof(outgoingReadings));
  // Uncomment below to print send result
  // Serial.println(result == ESP_OK ? "Sent with success" : "Error sending the data");
}
