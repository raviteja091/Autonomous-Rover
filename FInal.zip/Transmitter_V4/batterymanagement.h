float BatteryMeasure() {
  const int numReadings = 50;       // Number of readings to average
  float totalVoltage = 0.0;         // Accumulator for voltage readings

  // Take multiple readings to average for more stable voltage measurement
  for (int i = 0; i < numReadings; i++) {
    // Read the analog value, convert to voltage, and add to total
    totalVoltage += ((float)analogRead(36) / 4095) * 4.2;
    // Optional: Add delay if necessary for sensor stability
    // delay(10);
  }

  // Calculate the average voltage from the readings
  float voltage = totalVoltage / numReadings;

  // Map voltage range (4.2V to 3.7V) to percentage (100% to 0%)
  float percentage = ((voltage - 3.7) / (4.2 - 3.7)) * 100;

  // Clamp percentage between 0% and 100% to avoid out-of-bound values
  if (percentage > 100) {
    return 100;
  } else if (percentage < 0) {
    return 0;
  } else {
    return percentage;
  }
}
