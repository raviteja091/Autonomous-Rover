// Global variables for MPU9250 data
float pitch = 0.0;         // Holds the pitch angle
float roll = 0.0;          // Holds the roll angle
float yaw = 0.0;           // Holds the yaw angle

void IMU_init() {
  // Initialize I2C communication
  Wire.begin();
  delay(2000);             // Delay to allow MPU9250 to initialize

  // Setup MPU9250 with its I2C address
  if (!mpu.setup(0x68)) {  // 0x68 is the I2C address for MPU9250
    Serial.println("MPU9250 is not connected.");
    // Uncomment the lines below to stop execution if initialization fails
    // while (1) {
    //   delay(5000);      // Wait indefinitely if MPU9250 fails to initialize
    // }
  } else {
    Serial.println("MPU9250 Initialization is Successful");
  }
}

// Function to update pitch, roll, and yaw values from MPU9250
void updateMPUValues() {
  // Check if MPU9250 data is available for update
  if (mpu.update()) {
    static uint32_t prev_ms = millis();  // Store previous update time

    // Update values every 25 milliseconds to reduce data rate
    if (millis() - prev_ms > 25) {
      yaw = mpu.getYaw();               // Retrieve current yaw angle
      pitch = mpu.getPitch();            // Retrieve current pitch angle
      roll = mpu.getRoll();              // Retrieve current roll angle
      prev_ms = millis();                // Update previous time to current time
    }
  }
}
