// Global variables for Joystick 1
int joy1XVal = 0;           // Joystick 1 X-axis value
int joy1YVal = 0;           // Joystick 1 Y-axis value
int joy1ButtonState = 0;    // Joystick 1 Button state

// Global variables for Joystick 2
int joy2XVal = 0;           // Joystick 2 X-axis value
int joy2YVal = 0;           // Joystick 2 Y-axis value
int joy2ButtonState = 0;    // Joystick 2 Button state

// Global variables for Extra Buttons
int button1State = 0;       // Extra Button 1 state
int button2State = 0;       // Extra Button 2 state

// Pin definitions for Joystick 1
const int joy1X = 32;       // Joystick 1 X-axis pin (Analog)
const int joy1Y = 33;       // Joystick 1 Y-axis pin (Analog)
const int joy1Button = 16;  // Joystick 1 Button pin (Digital)

// Pin definitions for Joystick 2
const int joy2X = 34;       // Joystick 2 X-axis pin (Analog)
const int joy2Y = 35;       // Joystick 2 Y-axis pin (Analog)
const int joy2Button = 17;  // Joystick 2 Button pin (Digital)

// Pin definitions for Extra Buttons
const int button1 = 5;      // Extra Button 1 pin (Digital)
const int button2 = 18;     // Extra Button 2 pin (Digital)

void Button_Init() {
  // Configure joystick buttons and extra buttons as input with internal pull-up resistors
  pinMode(joy1Button, INPUT_PULLUP);
  pinMode(joy2Button, INPUT_PULLUP);
  pinMode(button1, INPUT_PULLUP);
  pinMode(button2, INPUT_PULLUP);

  Serial.println("Button Initialization Successful");
}

// Function to read joystick and button values
void readJoystickValues() {
  // Read Joystick 1 values
  joy1XVal = analogRead(joy1X);               // Read X-axis analog value
  joy1YVal = analogRead(joy1Y);               // Read Y-axis analog value
  joy1ButtonState = digitalRead(joy1Button);  // Read button state (pressed/released)

  // Read Joystick 2 values
  joy2XVal = analogRead(joy2X);               // Read X-axis analog value
  joy2YVal = analogRead(joy2Y);               // Read Y-axis analog value
  joy2ButtonState = digitalRead(joy2Button);  // Read button state (pressed/released)

  // Read Extra Button states
  button1State = digitalRead(button1);        // Read Extra Button 1 state
  button2State = digitalRead(button2);        // Read Extra Button 2 state
}
